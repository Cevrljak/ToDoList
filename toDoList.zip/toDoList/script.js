function ProveriUnos() {
    let input = document.querySelector(".podaci").value; 

    if (input.trim() === "") {
        alert("Molimo vas da unesete tekst!");
    } else {
        console.log("Uneseni tekst: " + input);
    }
}
