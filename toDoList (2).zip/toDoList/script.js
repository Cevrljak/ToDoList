//Checking area
function ProveriUnos() {
    let input = document.querySelector(".podaci").value; 

    if (input.trim() === "") {
        alert("Molimo vas da unesete tekst!");
    } else {
        console.log("Uneseni tekst: " + input);
    }
}
//Items-remove
function removeItem(element) {
    const listItem = element.closest('li'); 
    listItem.remove();
}
// Items-Add
function addItem() {
    const input = document.querySelector(".podaci");
    const taskText = input.value.trim(); 

    if (taskText === "") { 
        alert("Molimo vas da unesete tekst!");
        return; 
    }

    const list = document.getElementById('MyList');
    const listItem = document.createElement('li');
    listItem.className = 'first';

    
    const inputWrapper = document.createElement('div');
    inputWrapper.className = 'input-wrapper';

    
    const label = document.createElement('label');
    label.className = 'checkbox-container';

    
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';

    
    const checkmark = document.createElement('span');
    checkmark.className = 'checkmark';

    
    const taskTextSpan = document.createElement('span');
    taskTextSpan.className = 'task-text';
    taskTextSpan.textContent = taskText; 

    
    label.appendChild(checkbox);
    label.appendChild(checkmark);
    label.appendChild(taskTextSpan);

    
    const closeBtn = document.createElement('span');
    closeBtn.className = 'close-btn';
    closeBtn.textContent = '×'; 
    closeBtn.onclick = function() { removeItem(this); }; 

    
    inputWrapper.appendChild(label);
    inputWrapper.appendChild(closeBtn);

   
    listItem.appendChild(inputWrapper);

    
    list.appendChild(listItem);
    input.value = ""; 
}


function removeItem(element) {
    const listItem = element.closest('li'); 
    listItem.remove(); 
}